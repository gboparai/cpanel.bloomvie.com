import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PaymnetsService {

  private readonly RootURL:string=environment.apiUrl;
  constructor(private http:HttpClient) { }

getAllSubscriptionPlans(paginationBo:any):Observable<any>
{
  debugger;
  return this.http.post(this.RootURL+"/SubscriptionPlans/getSubscriptionPlanPayment",paginationBo)
}


getSubscriptionByID(id:number):Observable<any>
{
  debugger;
  return this.http.get(this.RootURL+"/SubscriptionPlans/getSubscriptionPlanPaymentById",{params:{id}})
}

getAllMasterStatus():Observable<any>
{
  debugger;
  return this.http.get(this.RootURL+"/SubscriptionPlans/getAllMasterStatus")
}
}
